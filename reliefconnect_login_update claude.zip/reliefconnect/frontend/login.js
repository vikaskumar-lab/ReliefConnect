(function () {
  const $ = (id) => document.getElementById(id);
  const errorBox = $("error");

  // Already signed in? Go straight to the dashboard.
  fetch("/api/auth/me").then((r) => { if (r.ok) window.location.replace("/"); }).catch(() => {});

  function showError(message) {
    errorBox.textContent = message;
    errorBox.hidden = false;
  }
  function clearError() { errorBox.hidden = true; }

  function selectTab(which) {
    const login = which === "login";
    $("tab-login").classList.toggle("active", login);
    $("tab-register").classList.toggle("active", !login);
    $("tab-login").setAttribute("aria-selected", login);
    $("tab-register").setAttribute("aria-selected", !login);
    $("login-form").hidden = !login;
    $("register-form").hidden = login;
    clearError();
  }
  $("tab-login").addEventListener("click", () => selectTab("login"));
  $("tab-register").addEventListener("click", () => selectTab("register"));

  document.querySelectorAll(".show").forEach((btn) => {
    btn.addEventListener("click", () => {
      const input = $(btn.dataset.target);
      const hidden = input.type === "password";
      input.type = hidden ? "text" : "password";
      btn.textContent = hidden ? "Hide" : "Show";
    });
  });

  async function post(url, data) {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(json.error || "Something went wrong. Please try again.");
    return json;
  }

  async function submit(form, url, data) {
    const button = form.querySelector(".submit");
    const label = button.textContent;
    clearError();
    button.disabled = true;
    button.textContent = "Please wait...";
    try {
      await post(url, data);
      window.location.replace("/");
    } catch (err) {
      showError(err.message);
      button.disabled = false;
      button.textContent = label;
    }
  }

  $("login-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const email = $("login-email").value.trim();
    const password = $("login-password").value;
    if (!email || !password) return showError("Enter your email and password.");
    submit(e.target, "/api/auth/login", { email, password });
  });

  $("register-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const password = $("reg-password").value;
    if (password.length < 8) return showError("Password must be at least 8 characters.");
    if (password !== $("reg-confirm").value) return showError("The two passwords do not match.");
    submit(e.target, "/api/auth/register", {
      full_name: $("reg-name").value.trim(),
      email: $("reg-email").value.trim(),
      phone: $("reg-phone").value.trim(),
      password,
      role: document.querySelector('input[name="role"]:checked').value,
    });
  });
})();
