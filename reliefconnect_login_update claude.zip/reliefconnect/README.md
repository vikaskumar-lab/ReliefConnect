# ReliefConnect | Disaster Relief Coordination Prototype
**Emergency Operations System**

ReliefConnect coordinates emergency help requests, shelters, volunteers, and relief supplies during disaster emergencies (e.g. floods). It features a multi-criteria prioritization algorithm, constrained spatial allocation, double-allocation prevention, and an immutable decision audit trail.

---

## 🚀 Quick Start in Command Prompt (CMD)

Open **Command Prompt (`cmd.exe`)** and run:

```cmd
cd "C:\Users\VIKAS KUMAR\.gemini\antigravity\scratch\reliefconnect"
python run_server.py
```

Open your browser to:
👉 **[http://localhost:8080](http://localhost:8080)**

---

## 🧪 Running the 100+ Flood Simulation Test Suite in CMD

To run the automated validation suite testing 120 synthetic flood requests, concurrency locking, and algorithmic fairness:

```cmd
cd "C:\Users\VIKAS KUMAR\.gemini\antigravity\scratch\reliefconnect"
python test_suite.py
```

### What the Test Suite Evaluates:
1. **Schema Initialization**: Verifies all 10 core entities (`users`, `incidents`, `locations`, `shelters`, `capacity_updates`, `inventory_items`, `help_requests`, `volunteers`, `allocations`, `assignment_history`).
2. **PostGIS / Haversine Distance**: Verifies great-circle geodesic distance calculations.
3. **Prioritization Scoring**: Verifies dynamic urgency weighting:
   $$S_{\text{req}} = 0.50 \cdot \text{Severity} + 0.30 \cdot \text{Vulnerability} + 0.15 \cdot \text{WaterLevel} + 0.05 \cdot \text{WaitDecay}$$
4. **100+ Synthetic Request Generation**: Spawns 120 requests across 3 realistic flood zones (Riverside Delta, Urban Basin, Suburbs).
5. **Zero Double-Allocation Guarantee**: Verifies strict 0 duplicate allocations across concurrent resources.
6. **Shelter & Inventory Invariants**: Verifies occupancy does not exceed total capacity and inventory balances stay positive.
7. **Explainability Audit Trail**: Verifies structured rationale logs explaining why each allocation decision was made.

---

## 📂 Project Architecture

```
reliefconnect/
├── backend/
│   ├── models.py           # Domain models, geospatial calculations & enums
│   ├── database.py         # 10 core entities, SQLite spatial engine & transaction locks
│   ├── algorithm.py        # Multi-criteria prioritization & constrained allocation engine
│   ├── simulator.py        # 100+ synthetic flood request generator & validation auditor
│   └── server.py           # Multi-threaded REST API server (Python stdlib)
├── frontend/
│   ├── index.html          # Interactive Emergency Operations Center Web Dashboard
│   ├── styles.css          # High-contrast disaster response theme & responsive styles
│   └── app.js              # Real-time state management, Leaflet/Vector maps, modals
├── schema_postgres_postgis.sql  # Production PostgreSQL + PostGIS schema DDL
├── run_server.py           # Main application launcher
├── test_suite.py           # Automated CLI validation runner
└── README.md               # Documentation & usage guide
```

---

## 🛡️ Safety & Ethics Safeguards

- **Emergency Notice Banner**: Persistent alert stating this is a training prototype and giving official emergency dispatch numbers (112 / 911).
- **Location Privacy Masking**: Toggle available on citizen request form that applies a ~500m fuzzy perimeter to obfuscate exact household coordinates for vulnerable persons while preserving district-level triage accuracy.

## Accounts, Login & Roles

The dashboard now requires sign-in. Visit `/login.html` to sign in or create an account.

| Role | Can do |
|---|---|
| Citizen (self-register) | Submit help requests, track their own requests, view shelters |
| Volunteer (self-register) | Everything a citizen can, plus view requests, volunteers, allocations |
| Shelter Manager | Update shelter occupancy and restock inventory, view audit trail |
| Relief Coordinator | Verify/reject requests, run allocation, run simulations, add shelters and volunteers |
| Administrator | Everything, including resetting the database |

Security notes: passwords are salted and hashed with scrypt, sessions live in an HttpOnly
cookie (Secure over HTTPS), login attempts are rate limited, and every API route checks the
signed-in user's role on the server.

Seeded staff accounts (`admin@reliefconnect.org`, `sarah.j@reliefconnect.org`,
`manager.shl-north-gym@reliefconnect.org`, `vol1@reliefconnect.org`) get their password from the
`RC_DEMO_PASSWORD` environment variable. If it is not set, a random password is printed in the
server console at startup.
